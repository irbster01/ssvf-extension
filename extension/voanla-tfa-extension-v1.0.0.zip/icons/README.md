# Extension icons placeholder
# Replace these with actual icon files (16x16, 48x48, 128x128 PNG images)
# For now, you can use any small PNG images or generate them using an icon generator
